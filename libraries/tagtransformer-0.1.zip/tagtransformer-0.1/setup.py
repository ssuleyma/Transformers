from setuptools import setup, find_packages

setup(name = 'tagtransformer',
	  version = '0.1',
	  description = 'data preprocessing transformers',
	  url = 'https://github.com',
	  author = 'IBM',
	  author_email = 'Safura.Suleymanova@ibm.com',
	  license = 'IBM',
	  packages = find_packages(),
	  zip_safe = False)