
from sklearn.base import BaseEstimator, TransformerMixin
import numpy as np
import re
from sklearn.preprocessing import LabelEncoder

class HostNameTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, feature_name):
        self.feature_name = feature_name

    def fit(self, X, y = None):
        return self

    def get_name(self, text):

        text = " ".join(re.split("[.-]",str(text)))
        letters_only = re.sub("[^a-zA-Z]", " ", text)
        multiple_letters_only =  re.sub(r"\b[a-zA-Z]\b", "", letters_only)

        lst_name = str(multiple_letters_only).lower().split()
        stopwords = set(['east','west','north','south','au','us','eu','gb','de','china','es','dal',"",
                         'bluemix','saopaulo','secondary','softlayer','softlayergo','com','net','mybluemix',
                         'small', 'medium','large','services','xlarge',
                         'fra','int','hkg','mex','tok','syd','lon','syd','toronto','hongkong','tor',
                         'sao','par','dallas','jp','prod','ng'])

        words = [i for i in lst_name if not i in stopwords]
        words = set(sorted(words))

        return " ".join(words)

    def transform(self, X, y = None):
        X.loc[:, "Processed Name"] = X[self.feature_name].apply(self.get_name)
        return X

class AmbiguityTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, feature_name):
        self.feature_name = feature_name

    def fit(self, X, y = None):
        return self

    def transform(self, X, y = None):
        X.loc[X['Name'].str.contains('IBM'), "Feat_1"] = X.loc[X['Name'].str.contains('IBM'),
                                                               self.feature_name].apply(lambda s: re.split("[-_]", s.split(".")[0])[1])
        X['Feat_1']= X['Feat_1'].fillna('0').astype('int')
        
        X.loc[X['Name'].str.contains('dev-dw-spark'), "Feat_2"] = X.loc[X['Name'].str.contains('dev-dw-spark'),
                                                                        self.feature_name].apply(lambda s: s.split(".")[0][-4:])
        X['Feat_2'] = X['Feat_2'].fillna('0')
        return X
    
class DeployerTransformer(BaseEstimator, TransformerMixin):
    def __init__(self, feature_name):
        self.feature_name = feature_name

    def fit(self, X, y = None):
        return self

    def transform(self, X, y = None):
        null_vals = ['unknown', 'nan','unlisted','none']
        X.loc[:,self.feature_name] = X[self.feature_name].apply(lambda s: re.sub(re.compile("|".join(null_vals)),"nan",str(s).lower()))
        return X[self.feature_name]

class FeatureSelector(BaseEstimator, TransformerMixin):
    def __init__(self, feature_names):
        self.feature_names = feature_names

    def fit(self, X, y = None):
        return self

    def transform(self, X, y = None):
        return X[self.feature_names]

class MyLabelEncoder(BaseEstimator, TransformerMixin):
    def fit(self, X, y = None):
        return self

    def transform(self, X, y = None):
        enc = LabelEncoder()
        encc = enc.fit(X)
        enc_data = enc.transform(X)

        return enc_data


class ArrayCaster(BaseEstimator, TransformerMixin):
    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        return np.transpose(np.matrix(X))
